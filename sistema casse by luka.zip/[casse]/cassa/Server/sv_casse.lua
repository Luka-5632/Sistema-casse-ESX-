ESX = exports["es_extended"]:getSharedObject()
local openedChests = {}

RegisterServerEvent('custom_chests:openChest')
AddEventHandler('custom_chests:openChest', function(chest)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)

    if not xPlayer then return end

    local chestId = tostring(chest.x) .. tostring(chest.y) .. tostring(chest.z)

    if openedChests[chestId] then
        TriggerClientEvent('custom_chests:showNotification', src, 'Questa cassa è già stata aperta! Aspetta il riavvio della risorsa.')
        return
    end

    openedChests[chestId] = true

    for _, item in ipairs(chest.items) do
        local success = xPlayer.addInventoryItem(item.name, item.amount)

        if success then
            print("Aggiunto " .. item.amount .. " di " .. item.name .. " al giocatore " .. xPlayer.identifier)
        else
            print("Errore nell'aggiunta di " .. item.name .. " al giocatore " .. xPlayer.identifier)
        end
    end

    TriggerClientEvent('custom_chests:showNotification', src, 'Hai ricevuto i tuoi oggetti!')
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        openedChests = {} 
        print("Casse riavviate.") 
    end
end)

RegisterServerEvent('custom_chests:resetChests')
AddEventHandler('custom_chests:resetChests', function()
    openedChests = {}
    TriggerClientEvent('custom_chests:showNotification', source, 'Tutte le casse sono state resettate!')
end)
