CREATE TABLE IF NOT EXISTS `user_inventory` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `player` VARCHAR(50) NOT NULL,
    `item` VARCHAR(50) NOT NULL,
    `quantity` INT NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE KEY `player_item` (`player`, `item`)
);
