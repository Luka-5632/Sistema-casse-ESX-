ESX = exports["es_extended"]:getSharedObject()

local spawnedProps = {}

Citizen.CreateThread(function()
    for _, chest in ipairs(Config.Chests) do
        local propHash = GetHashKey(Config.ChestModel)
        RequestModel(propHash)
        while not HasModelLoaded(propHash) do
            Citizen.Wait(100)
        end

        local prop = CreateObject(propHash, chest.x, chest.y, chest.z - 1.0, false, false, true)
        PlaceObjectOnGroundProperly(prop)
        FreezeEntityPosition(prop, true)
        table.insert(spawnedProps, prop)
    end
end)

function ShowHelpNotification(text)
    BeginTextCommandDisplayHelp("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayHelp(0, false, true, -1)
end

function PlayChestOpeningAnimation()
    local playerPed = PlayerPedId()
    RequestAnimDict("anim@mp_fireworks")
    while not HasAnimDictLoaded("anim@mp_fireworks") do
        Citizen.Wait(10)
    end

    TaskPlayAnim(playerPed, "anim@mp_fireworks", "place_firework_box2", 8.0, -8, -1, 1, 0, false, false, false)
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        local nearChest = false

        for _, chest in ipairs(Config.Chests) do
            local chestPos = vector3(chest.x, chest.y, chest.z)
            local distance = #(playerCoords - chestPos)

            if distance < Config.InteractDistance then
                nearChest = true
                ShowHelpNotification("Premi ~INPUT_CONTEXT~ per aprire la cassa")

                if IsControlJustPressed(0, Config.InteractKey) then
                    PlayChestOpeningAnimation()

                    if lib.progressBar({
                        duration = 2000,
                        label = 'Aprendo la cassa',
                        useWhileDead = false,
                        canCancel = false,
                        disable = {},
                        anim = {
                            dict = 'anim@mp_fireworks',
                            clip = 'lift_box' 
                        },
                    }) then 
                        ClearPedTasks(playerPed)
                        TriggerServerEvent('custom_chests:openChest', chest)
                    end
                end
            end
        end

        if not nearChest then
            Citizen.Wait(500)
        end
    end
end)

RegisterNetEvent('custom_chests:showNotification')
AddEventHandler('custom_chests:showNotification', function(message)
    ESX.ShowNotification(message)
end)
