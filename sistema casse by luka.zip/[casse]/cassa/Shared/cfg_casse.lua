
Config.Chests = {
    { x = -206.58, y = -1011.11, z = 30.14, items = { { name = "water", amount = 1 }, { name = "bread", amount = 2 } } },
    { x = 125.68, y = -234.22, z = 53.92, items = { { name = "ammo", amount = 5 }, { name = "bandage", amount = 1 } } }
}

-- non toccare
Config.ChestModel = "prop_champ_box_01"  -- Modello di esempio di una scatola
Config.InteractKey = 38
Config.InteractDistance = 2.0